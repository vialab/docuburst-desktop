package test.algorithm;

public class JTestAlgorithm {
	
	public static void main(String []args) {
		String argumentos[] = new String[] {"3", "1", 
				"./es/project/utilidades/stopwords.txt","./es/project/utilidades/mail.properties"};
	}
}

