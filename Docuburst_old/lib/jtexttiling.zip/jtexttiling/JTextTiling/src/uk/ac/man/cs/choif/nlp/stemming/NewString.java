package uk.ac.man.cs.choif.nlp.stemming;

/* author:   Fotis Lazarinis (actually I translated from C to Java)
   date:     June 1997
   address:  Psilovraxou 12, Agrinio, 30100

   comments: Compile it, import the Porter class into you program and create an instance.
	     Then use the stripAffixes method of this method which takes a String as 
			 input and returns the stem of this String again as a String.

*/ 

class NewString {
  public String str;

  NewString() {
	 str = "";
  }  
}